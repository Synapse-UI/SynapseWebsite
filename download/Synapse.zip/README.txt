Welcome to Synapse! We are glad to have you here.

To start, run Synapse X.exe.

If you need any help, you can contact our support team at https://discord.gg/ATE3Q5aahJ.

Enjoy!